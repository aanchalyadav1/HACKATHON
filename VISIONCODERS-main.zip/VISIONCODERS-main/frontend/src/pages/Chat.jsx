export default function Chat(){
  return <div className='p-4 text-white'>Chat Page Loaded</div>
}