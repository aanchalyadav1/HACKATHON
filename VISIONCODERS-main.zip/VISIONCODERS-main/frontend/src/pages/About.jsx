export default function About(){
  return <div className='p-4 text-white'>About ALIS</div>
}