export default function Register(){
  return <div className='p-4 text-white'>Register Page</div>
}