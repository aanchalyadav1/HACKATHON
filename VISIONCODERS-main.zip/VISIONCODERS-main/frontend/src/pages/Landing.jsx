export default function Landing(){
  return <div className='p-4 text-white'>Landing Page Loaded</div>
}