export default function Dashboard(){
  return <div className='p-4 text-white'>Dashboard Loaded</div>
}