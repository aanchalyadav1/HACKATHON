export default function AgentTag({ name }){
  return <span className='text-xs px-2 py-1 bg-white/10 rounded'>{name}</span>
}