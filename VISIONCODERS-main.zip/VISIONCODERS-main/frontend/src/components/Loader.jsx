export default function Loader(){
  return (
    <div className='text-white/70 animate-pulse'>
      Loading...
    </div>
  );
}