export default function TypingIndicator(){
  return <div className='opacity-70 text-sm'>ALIS is typing...</div>
}